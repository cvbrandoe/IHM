package fr.paris.mvc;

public class Model {

	String valeur;

	public String getValeur() {		
		return valeur;
	}

	public void setValeur(String valeur) {
		this.valeur = valeur;
	}
	
}
